function validateForm() {
  let x1 = document.forms["myForm"]["firstname"].value;
  if (x1 == "") {
    alert("First Name must be filled out");
    return false;
  }

  let x2 = document.forms["myForm"]["lastname"].value;
  if (x2 == "") {
    alert("Last Name must be filled out");
    return false;
  }

let x3 = document.forms["myForm"]["email"].value;
  if (x3 == "") {
    alert("E-mail must be filled out");
    return false;
  }

let x4 = document.forms["myForm"]["contact"].value;
  if (x4 == "") {
    alert("Contact must be filled out");
    return false;
  }

let x5 = document.forms["myForm"]["email"].value;
  if (x5 == "") {
    alert("E-mail Name must be filled out");
    return false;
  }

let x6 = document.forms["myForm"]["subject"].value;
  if (x6 == "") {
    alert("Subject must be filled out");
    return false;
  }


} 