myname = prompt("Enter Your Name");
studentID = prompt("Enter Your Student ID");

alert("Your Name = " + myname);
alert("Your StudentID = " + studentID);