var myColor = ['Red', 'Green', 'White', 'Black'];
document.write(myColor.toString());
document.write("<br>" + myColor.join());
document.write("<br>" + myColor.join('+'));