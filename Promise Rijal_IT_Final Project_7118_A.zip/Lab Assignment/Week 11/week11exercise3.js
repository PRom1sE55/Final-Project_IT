eng = parseInt(prompt("Enter Marks In English"));
maths = parseInt(prompt("Enter Marks In Maths"));
science = parseInt(prompt("Enter Marks In Science"));
total = (eng + maths + science)/3;

document.write("Marks in English = " + eng);
document.write("<br>Marks in Maths= " + maths);
document.write("<br>Marks in  Science= " + science);
document.write("<br>Total = " + total);
document.write("<br>")

if(total>=80 && total<=100)
    document.write("Distinction");
else if(total >=60 && total<80)
    document.write("First Divsion");
else if(total >=50 && total<60)
    document.write("Second Divsion");
else if(total >=40 && total<40)
    document.write("Third Division");
else
    document.write("Fail");