var names = ['One', 'Two', 'Three', 'Four'];
var image = ['<img src = 1.jpg></img>', '<img src = 2.jpg></img>', '<img src = 3.jpg></img>', '<img src = 4.jpg></img>'];

var text = document.getElementById('text');
var table = '<table><thead><tr><th>S.N.</th><th>Name</th><th>Image</th></tr></thead>';

for (var i = 0; i < names.length; i++){
    table += '<tr><td>' + ( i + 1 ) + '</td><td>'+ names[i] + '</td><td>' + image[i] + '</td></tr>';
}

table += "</table>"
text.innerHTML = table;