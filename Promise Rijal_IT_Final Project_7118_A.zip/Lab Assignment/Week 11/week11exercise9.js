var array = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
s = 0;
p = 1;
for (i = 0; i < array.length; i++) {
    s += array[i];
    p *= array[i];   
}
document.write("Sum = " + s);
document.write("<br>" + "Product = " + p);