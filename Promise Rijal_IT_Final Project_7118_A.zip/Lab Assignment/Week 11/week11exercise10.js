function calculatearea(length, breadth) {
    area = length * breadth
    document.write("Length = " + length);
    document.write("<br>" + "Breadth = " + breadth);
    document.write("<br>" + "Area = " + area);
}

calculatearea(3,5);

