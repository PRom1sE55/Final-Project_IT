numeric = 2;
float = 3.14;
string = "Hello";
bool = 1;

document.write("Numeric = " + numeric);
document.write("<br>Float = " + float);
document.write("<br>String = " + string);
document.write("<br>Bool = " + bool);
document.write("<br>")
if(bool = 1)
    document.write("true");
else
    document.write("false");