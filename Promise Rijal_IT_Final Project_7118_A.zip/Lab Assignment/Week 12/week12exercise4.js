function changeColor(){
    document.getElementById('paragraph').style.backgroundColor = "lightblue";
}