a = prompt("Enter The Password");
b = prompt("Enter The Password Again");

if(a == b){
    alert("Your password is set!")
}
else{
    alert("Your password's text fields values do not match!")
}