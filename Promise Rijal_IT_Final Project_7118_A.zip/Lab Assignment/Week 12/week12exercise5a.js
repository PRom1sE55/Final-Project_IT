function isNaN(x) {
x = parseInt(prompt("Enter a Number"));
if(x !== x) {
    alert('NaN.');
}
else{
    alert('NOT a NaN.');
}
}
isNaN(NaN);