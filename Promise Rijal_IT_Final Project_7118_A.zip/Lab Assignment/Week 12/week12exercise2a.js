function changeText(){
    document.getElementById('change').innerHTML = "Oh Yeah";
}