function mOut(){
    document.getElementById('second').innerHTML = "Mouse Over Me";
}