function startTime(){
    const today = new Date();
    let y = today.getFullYear();
    let mth = today.getMonth();
    let d = today.getDate();
    let h = today.getHours();
    let m = today.getMinutes();
    let s = today.getSeconds();

    document.getElementById('date').innerHTML = y + "-" + mth + "-" + d;
    document.getElementById('time').innerHTML = h + ":" + m + ":" + s;
    setTimeout(startTime, 1000);
}

function checkTime(i) {
    if(i < 10){i = "0" + i}; //add zero in front of number;
    return i;
}